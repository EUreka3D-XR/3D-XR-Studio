import axios from "axios";

// Base URL API configurabile
const API = (import.meta?.env?.VITE_API_BASE_URL || "http://localhost:5000").replace(/\/+$/, "");

// Utility per ottenere gli header di autenticazione
const getAuthHeaders = () => {
  const token = localStorage.getItem("token");
  return { Authorization: `Bearer ${token}` };
};

/**
 * API per la gestione dei Punti di Interesse (POI)
 */
const poisApi = {
  /**
   * Crea un nuovo POI
   * @param {Object} poiData - Dati del POI
   * @param {string} poiData.environment_id - ID dell'ambiente
   * @param {string} poiData.label - Nome del POI
   * @param {number} poiData.latitude - Latitudine
   * @param {number} poiData.longitude - Longitudine
   * @param {number} poiData.rel_x - Posizione relativa X in metri
   * @param {number} poiData.rel_y - Posizione relativa Y in metri
   * @param {string} poiData.description - Descrizione (opzionale)
   * @param {string} poiData.extra_media_url - URL media aggiuntivo (opzionale)
   * @returns {Promise<Object>} POI creato
   */
  async createPoi(poiData) {
    try {
      const response = await axios.post(
        `${API}/api/env_pois`,
        {
          environment_id: poiData.environment_id,
          label: poiData.label,
          latitude: poiData.latitude,
          longitude: poiData.longitude,
          rel_x: poiData.rel_x,
          rel_y: poiData.rel_y,
          description: poiData.description || null,
          extra_media_url: poiData.extra_media_url || null
        },
        { headers: getAuthHeaders() }
      );
      return response.data;
    } catch (error) {
      console.error("Errore nella creazione del POI:", error);
      throw new Error(
        error.response?.data?.message || "Errore nella creazione del POI"
      );
    }
  },

  /**
   * Recupera la lista dei POI per un ambiente
   * @param {string} environmentId - ID dell'ambiente
   * @returns {Promise<Array>} Lista dei POI
   */
  async listPois(environmentId) {
    try {
      const response = await axios.get(
        `${API}/api/env_pois`,
        {
          params: { environment_id: environmentId },
          headers: getAuthHeaders()
        }
      );
      return response.data;
    } catch (error) {
      console.error("Errore nel recupero dei POI:", error);
      throw new Error(
        error.response?.data?.message || "Errore nel recupero dei POI"
      );
    }
  },

  /**
   * Recupera la lista dei POI con il conteggio dei media associati
   * @param {string} environmentId - ID dell'ambiente
   * @returns {Promise<Array>} Lista dei POI con media_count
   */
  async listPoisWithMediaCount(environmentId) {
    try {
      const response = await axios.get(
        `${API}/api/env_pois/with-media-count`,
        {
          params: { environment_id: environmentId },
          headers: getAuthHeaders()
        }
      );
      return response.data;
    } catch (error) {
      console.error("Errore nel recupero dei POI con conteggio media:", error);
      // Fallback: usa listPois normale e aggiungi media_count = 0
      try {
        const pois = await this.listPois(environmentId);
        return pois.map(poi => ({ ...poi, media_count: 0 }));
      } catch (fallbackError) {
        throw new Error(
          error.response?.data?.message || "Errore nel recupero dei POI"
        );
      }
    }
  },

  /**
   * Recupera i dettagli di un POI con i media associati
   * @param {string} poiId - ID del POI
   * @returns {Promise<Object>} Dettagli del POI con media
   */
  async getPoiDetails(poiId) {
    try {
      const response = await axios.get(
        `${API}/api/env_pois/${poiId}`,
        { headers: getAuthHeaders() }
      );
      return response.data;
    } catch (error) {
      console.error("Errore nel recupero dei dettagli del POI:", error);
      throw new Error(
        error.response?.data?.message || "Errore nel recupero dei dettagli del POI"
      );
    }
  },

  /**
   * Aggiorna un POI
   * @param {string} poiId - ID del POI
   * @param {Object} poiData - Dati da aggiornare
   * @returns {Promise<Object>} POI aggiornato
   */
  async updatePoi(poiId, poiData) {
    try {
      const response = await axios.put(
        `${API}/api/env_pois/${poiId}`,
        poiData,
        { headers: getAuthHeaders() }
      );
      return response.data;
    } catch (error) {
      console.error("Errore nell'aggiornamento del POI:", error);
      throw new Error(
        error.response?.data?.message || "Errore nell'aggiornamento del POI"
      );
    }
  },

  /**
   * Elimina un POI
   * @param {string} poiId - ID del POI
   * @returns {Promise<void>}
   */
  async deletePoi(poiId) {
    try {
      await axios.delete(
        `${API}/api/env_pois/${poiId}`,
        { headers: getAuthHeaders() }
      );
    } catch (error) {
      console.error("Errore nell'eliminazione del POI:", error);
      throw new Error(
        error.response?.data?.message || "Errore nell'eliminazione del POI"
      );
    }
  },

  // ================================
  // GESTIONE MEDIA POI
  // ================================

  /**
   * Recupera la lista dei media di un POI
   * @param {string} poiId - ID del POI
   * @returns {Promise<Array>} Lista dei media del POI
   */
  async listPoiMedia(poiId) {
    try {
      const response = await axios.get(
        `${API}/api/env_pois/${poiId}/media`,
        { headers: getAuthHeaders() }
      );
      return response.data;
    } catch (error) {
      console.error("Errore nel recupero dei media del POI:", error);
      throw new Error(
        error.response?.data?.message || "Errore nel recupero dei media del POI"
      );
    }
  },

  /**
   * Aggiunge un media a un POI
   * @param {string} poiId - ID del POI
   * @param {Object} mediaData - Dati del media
   * @param {string} mediaData.type - Tipo media (image, video, url, other)
   * @param {string} mediaData.title - Titolo del media (opzionale)
   * @param {string} mediaData.url - URL del media
   * @returns {Promise<Object>} Media creato
   */
  async createPoiMedia(poiId, mediaData) {
    try {
      const response = await axios.post(
        `${API}/api/env_pois/${poiId}/media`,
        {
          type: mediaData.type,
          title: mediaData.title || null,
          url: mediaData.url
        },
        { headers: getAuthHeaders() }
      );
      return response.data;
    } catch (error) {
      console.error("Errore nell'aggiunta del media al POI:", error);
      throw new Error(
        error.response?.data?.message || "Errore nell'aggiunta del media al POI"
      );
    }
  },

  /**
   * Aggiorna un media di un POI
   * @param {string} mediaId - ID del media
   * @param {Object} mediaData - Dati da aggiornare
   * @returns {Promise<Object>} Media aggiornato
   */
  async updatePoiMedia(mediaId, mediaData) {
    try {
      const response = await axios.put(
        `${API}/api/poi-media/${mediaId}`,
        mediaData,
        { headers: getAuthHeaders() }
      );
      return response.data;
    } catch (error) {
      console.error("Errore nell'aggiornamento del media del POI:", error);
      throw new Error(
        error.response?.data?.message || "Errore nell'aggiornamento del media"
      );
    }
  },

  /**
   * Elimina un media di un POI
   * @param {string} mediaId - ID del media
   * @returns {Promise<void>}
   */
  async deletePoiMedia(mediaId) {
    try {
      await axios.delete(
        `${API}/api/poi-media/${mediaId}`,
        { headers: getAuthHeaders() }
      );
    } catch (error) {
      console.error("Errore nell'eliminazione del media del POI:", error);
      throw new Error(
        error.response?.data?.message || "Errore nell'eliminazione del media"
      );
    }
  },

  // ================================
  // UTILITY E VALIDAZIONE
  // ================================

  /**
   * Valida i dati di un POI
   * @param {Object} poiData - Dati da validare
   * @returns {Object} Risultato validazione {isValid, errors}
   */
  validatePoiData(poiData) {
    const errors = [];
    
    if (!poiData.environment_id) {
      errors.push("L'ID dell'ambiente è obbligatorio");
    }
    
    if (!poiData.label || poiData.label.trim().length === 0) {
      errors.push("Il nome del POI è obbligatorio");
    }
    
    if (!poiData.latitude || !isFinite(Number(poiData.latitude))) {
      errors.push("Latitudine non valida");
    }
    
    if (!poiData.longitude || !isFinite(Number(poiData.longitude))) {
      errors.push("Longitudine non valida");
    }
    
    if (poiData.rel_x !== null && !isFinite(Number(poiData.rel_x))) {
      errors.push("Posizione relativa X non valida");
    }
    
    if (poiData.rel_y !== null && !isFinite(Number(poiData.rel_y))) {
      errors.push("Posizione relativa Y non valida");
    }
    
    return {
      isValid: errors.length === 0,
      errors
    };
  },

  /**
   * Valida i dati di un media POI
   * @param {Object} mediaData - Dati da validare
   * @returns {Object} Risultato validazione {isValid, errors}
   */
  validatePoiMediaData(mediaData) {
    const errors = [];
    const validTypes = ['image', 'video', 'url', 'other'];
    
    if (!mediaData.type || !validTypes.includes(mediaData.type)) {
      errors.push("Tipo di media non valido");
    }
    
    if (!mediaData.url || mediaData.url.trim().length === 0) {
      errors.push("URL del media è obbligatorio");
    }
    
    // Validazione specifica per video YouTube
    if (mediaData.type === 'video') {
      const youtubeRegex = /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.be)\/.+/;
      if (!youtubeRegex.test(mediaData.url)) {
        errors.push("Per i video sono supportati solo URL YouTube");
      }
    }
    
    // Validazione URL generale
    try {
      new URL(mediaData.url);
    } catch {
      errors.push("URL non valido");
    }
    
    return {
      isValid: errors.length === 0,
      errors
    };
  },

  /**
   * Calcola coordinate relative in metri rispetto a un punto di riferimento
   * @param {number} lat - Latitudine del POI
   * @param {number} lng - Longitudine del POI
   * @param {number} refLat - Latitudine di riferimento
   * @param {number} refLng - Longitudine di riferimento
   * @returns {Object} Coordinate relative {rel_x, rel_y}
   */
  calculateRelativePosition(lat, lng, refLat, refLng) {
    const lat0 = Number(refLat);
    const lng0 = Number(refLng);
    
    if (!isFinite(lat0) || !isFinite(lng0)) {
      return { rel_x: null, rel_y: null };
    }
    
    const dLat = (lat - lat0) * (Math.PI / 180);
    const dLng = (lng - lng0) * (Math.PI / 180);
    const R = 6371000; // Raggio Terra in metri
    const meanLat = ((lat + lat0) / 2) * (Math.PI / 180);
    const rel_x = R * dLng * Math.cos(meanLat);
    const rel_y = R * dLat;
    
    return { rel_x, rel_y };
  },

  /**
   * Estrae l'ID di un video YouTube dall'URL
   * @param {string} url - URL YouTube
   * @returns {string|null} ID del video o null se non valido
   */
  extractYouTubeVideoId(url) {
    const regex = /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/;
    const match = url.match(regex);
    return match ? match[1] : null;
  },

  /**
   * Verifica se un URL è di YouTube
   * @param {string} url - URL da verificare
   * @returns {boolean} True se è un URL YouTube valido
   */
  isValidYouTubeUrl(url) {
    const youtubeRegex = /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.be)\/.+/;
    return youtubeRegex.test(url);
  },

  // E per la funzione listPoisWithMediaCount, dato che l'endpoint non esiste nel backend:
async listPoisWithMediaCount(environmentId) {
  try {
    // Usa l'endpoint esistente con fallback al conteggio manuale
    const pois = await this.listPois(environmentId);
    
    // Per ogni POI, conta i media (se necessario)
    const poisWithCount = await Promise.all(
      pois.map(async (poi) => {
        try {
          const media = await this.listPoiMedia(poi.id);
          return { ...poi, media_count: media.length };
        } catch (error) {
          return { ...poi, media_count: 0 };
        }
      })
    );
    
    return poisWithCount;
  } catch (error) {
    console.error("Errore nel recupero dei POI con conteggio media:", error);
    throw new Error(
      error.response?.data?.message || "Errore nel recupero dei POI"
    );
  }
},

  /**
   * Crea i dati completi per un nuovo POI con coordinate relative calcolate
   * @param {Object} basicData - Dati base del POI
   * @param {string} basicData.environment_id - ID dell'ambiente
   * @param {string} basicData.label - Nome del POI
   * @param {number} basicData.latitude - Latitudine
   * @param {number} basicData.longitude - Longitudine
   * @param {number} refLat - Latitudine di riferimento dell'ambiente
   * @param {number} refLng - Longitudine di riferimento dell'ambiente
   * @param {string} description - Descrizione (opzionale)
   * @returns {Object} Dati POI completi con coordinate relative
   */
  createPoiDataWithRelativeCoords(basicData, refLat, refLng, description = null) {
    const { rel_x, rel_y } = this.calculateRelativePosition(
      basicData.latitude,
      basicData.longitude,
      refLat,
      refLng
    );
    
    return {
      environment_id: basicData.environment_id,
      label: basicData.label,
      latitude: basicData.latitude,
      longitude: basicData.longitude,
      rel_x,
      rel_y,
      description,
      extra_media_url: null
    };
  }
};

export default poisApi;