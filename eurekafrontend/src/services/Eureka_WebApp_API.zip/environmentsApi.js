import axios from "axios";

// Base URL API configurabile
const API = (import.meta?.env?.VITE_API_BASE_URL || "http://localhost:5000").replace(/\/+$/, "");

// Utility per ottenere gli header di autenticazione
const getAuthHeaders = () => {
  const token = localStorage.getItem("token");
  return { Authorization: `Bearer ${token}` };
};

/**
 * API per la gestione degli ambienti
 */
const environmentsApi = {
  /**
   * Crea un nuovo ambiente
   * @param {Object} environmentData - Dati dell'ambiente
   * @param {string} environmentData.name - Nome dell'ambiente
   * @param {number} environmentData.latitude - Latitudine
   * @param {number} environmentData.longitude - Longitudine
   * @param {Object} environmentData.surface_area - Area di superficie con 4 coordinate
   * @returns {Promise<Object>} Ambiente creato
   */
  async createEnvironment(environmentData) {
    try {
      const response = await axios.post(
        `${API}/api/environments/create`,
        environmentData,
        { headers: getAuthHeaders() }
      );
      return response.data;
    } catch (error) {
      console.error("Errore nella creazione dell'ambiente:", error);
      throw new Error(
        error.response?.data?.message || "Errore nella creazione dell'ambiente"
      );
    }
  },

  /**
   * Aggiorna un ambiente esistente
   * @param {string} environmentId - ID dell'ambiente
   * @param {Object} environmentData - Dati dell'ambiente da aggiornare
   * @returns {Promise<Object>} Ambiente aggiornato
   */
  async updateEnvironment(environmentId, environmentData) {
    try {
      const response = await axios.put(
        `${API}/api/environments/update/${environmentId}`,
        environmentData,
        { headers: getAuthHeaders() }
      );
      return response.data;
    } catch (error) {
      console.error("Errore nell'aggiornamento dell'ambiente:", error);
      throw new Error(
        error.response?.data?.message || "Errore nell'aggiornamento dell'ambiente"
      );
    }
  },

  /**
   * Recupera i dettagli di un ambiente
   * @param {string} environmentId - ID dell'ambiente
   * @returns {Promise<Object>} Dettagli dell'ambiente con env_objects e objects
   */
  async getEnvironmentDetails(environmentId) {
    try {
      const response = await axios.get(
        `${API}/api/environments/detail/${environmentId}`,
        { headers: getAuthHeaders() }
      );
      return response.data;
    } catch (error) {
      console.error("Errore nel recupero dei dettagli dell'ambiente:", error);
      throw new Error(
        error.response?.data?.message || "Errore nel recupero dell'ambiente"
      );
    }
  },

  /**
   * Recupera la lista di tutti gli ambienti dell'utente
   * @returns {Promise<Array>} Lista degli ambienti
   */
  async listEnvironments() {
    try {
      const response = await axios.get(
        `${API}/api/environments`,
        { headers: getAuthHeaders() }
      );
      return response.data;
    } catch (error) {
      console.error("Errore nel recupero della lista ambienti:", error);
      throw new Error(
        error.response?.data?.message || "Errore nel recupero degli ambienti"
      );
    }
  },

  /**
   * Elimina un ambiente
   * @param {string} environmentId - ID dell'ambiente
   * @returns {Promise<void>}
   */
  async deleteEnvironment(environmentId) {
    try {
      await axios.delete(
        `${API}/api/environments/${environmentId}`,
        { headers: getAuthHeaders() }
      );
    } catch (error) {
      console.error("Errore nell'eliminazione dell'ambiente:", error);
      throw new Error(
        error.response?.data?.message || "Errore nell'eliminazione dell'ambiente"
      );
    }
  },

  /**
   * Utility per calcolare coordinate relative in metri
   * @param {number} lat - Latitudine del punto
   * @param {number} lng - Longitudine del punto
   * @param {number} refLat - Latitudine di riferimento
   * @param {number} refLng - Longitudine di riferimento
   * @returns {Object} Coordinate relative {rel_x, rel_y}
   */
  toRelativeMeters(lat, lng, refLat, refLng) {
    const lat0 = Number(refLat);
    const lng0 = Number(refLng);
    
    if (!isFinite(lat0) || !isFinite(lng0)) {
      return { rel_x: null, rel_y: null };
    }
    
    const dLat = (lat - lat0) * (Math.PI / 180);
    const dLng = (lng - lng0) * (Math.PI / 180);
    const R = 6371000; // Raggio Terra in metri
    const meanLat = ((lat + lat0) / 2) * (Math.PI / 180);
    const rel_x = R * dLng * Math.cos(meanLat);
    const rel_y = R * dLat;
    
    return { rel_x, rel_y };
  },

  /**
   * Valida i dati di un ambiente prima della creazione/aggiornamento
   * @param {Object} environmentData - Dati da validare
   * @returns {Object} Risultato validazione {isValid, errors}
   */
  validateEnvironmentData(environmentData) {
    const errors = [];
    
    // Validazione nome
    if (!environmentData.name || environmentData.name.trim().length === 0) {
      errors.push("Il nome dell'ambiente è obbligatorio");
    }
    
    // Validazione coordinate centrali
    if (!environmentData.latitude || !isFinite(Number(environmentData.latitude))) {
      errors.push("Latitudine non valida");
    }
    
    if (!environmentData.longitude || !isFinite(Number(environmentData.longitude))) {
      errors.push("Longitudine non valida");
    }
    
    // Validazione superficie (opzionale ma se presente deve essere completa)
    if (environmentData.surface_area) {
      const vertices = ['topLeft', 'topRight', 'bottomLeft', 'bottomRight'];
      const coords = ['lat', 'lng'];
      
      for (const vertex of vertices) {
        if (!environmentData.surface_area[vertex]) {
          errors.push(`Coordinate ${vertex} mancanti nella superficie`);
          continue;
        }
        
        for (const coord of coords) {
          const value = environmentData.surface_area[vertex][coord];
          if (!value || !isFinite(Number(value))) {
            errors.push(`Coordinata ${vertex}.${coord} non valida`);
          }
        }
      }
    }
    
    return {
      isValid: errors.length === 0,
      errors
    };
  }
};

export default environmentsApi;