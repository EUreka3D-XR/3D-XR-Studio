// src/services/toursApi.js
// Wrapper axios per le API dei Percorsi (tour_routes) e delle Tappe (tour_stops)

import axios from "axios";

// Base URL (Vite): definisci VITE_API_BASE_URL, es. "http://localhost:5000"
const BASE_URL =
  (import.meta?.env?.VITE_API_BASE_URL || "http://localhost:5000").replace(
    /\/+$/,
    ""
  );

const api = axios.create({
  baseURL: `${BASE_URL}/api`,
  headers: { "Content-Type": "application/json" },
});

// Interceptor: aggiunge automaticamente il token JWT se presente
api.interceptors.request.use((config) => {
  const token = localStorage.getItem("token");
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Helper per uniformare gli errori
function unwrap(promise) {
  return promise
    .then((res) => res.data)
    .catch((err) => {
      const message =
        err?.response?.data?.error ||
        err?.response?.data?.message ||
        err?.message ||
        "Request failed";
      const e = new Error(message);
      e.status = err?.response?.status;
      e.data = err?.response?.data;
      throw e;
    });
}

/* =========================
 * ROUTE (percorsi) -> /api/tour_routes
 * ========================= */

/**
 * Lista percorsi di un ambiente
 * @param {{ environmentId?: number|string }} params
 */
function listRoutes({ environmentId } = {}) {
  const params = {};
  if (environmentId != null) params.environment_id = environmentId;
  return unwrap(api.get("/tour_routes", { params }));
}

/**
 * Dettaglio di una rotta
 * @param {number|string} routeId
 */
function getRoute(routeId) {
  return unwrap(api.get(`/tour_routes/${routeId}`));
}

/**
 * Crea una rotta
 * payload: { environment_id, name, description?, is_active? }
 */
function createRoute(payload) {
  return unwrap(api.post("/tour_routes", payload));
}

/**
 * Aggiorna una rotta
 * payload: { name?, description?, is_active? }
 */
function updateRoute(routeId, payload) {
  return unwrap(api.put(`/tour_routes/${routeId}`, payload));
}

/**
 * Elimina (soft-delete) una rotta
 */
function deleteRoute(routeId) {
  return unwrap(api.delete(`/tour_routes/${routeId}`));
}

/* =========================
 * STOPS (tappe) -> /api/tour_stops
 * ========================= */

/**
 * Lista tappe di una rotta (ordinate)
 * @param {number|string} routeId
 */
function listStops(routeId) {
  return unwrap(api.get("/tour_stops", { params: { route_id: routeId } }));
}

/**
 * Crea una tappa
 * stop: {
 *   label, latitude, longitude,
 *   description?, rel_x?, rel_y?, rel_z?, extra_media_url?,
 *   position? (alias: order_index?)
 * }
 */
function createStop(routeId, stop) {
  const payload = {
    ...stop,
    route_id: routeId,
  };
  // compat: se arriva order_index convertirlo in position
  if (payload.order_index != null && payload.position == null) {
    payload.position = payload.order_index;
    delete payload.order_index;
  }
  return unwrap(api.post("/tour_stops", payload));
}

/**
 * Aggiorna una tappa (anche il riordino tramite 'position')
 * updates parziale: stessi campi di createStop senza route_id
 */
function updateStop(stopId, updates) {
  const payload = { ...updates };
  if (payload.order_index != null && payload.position == null) {
    payload.position = payload.order_index;
    delete payload.order_index;
  }
  return unwrap(api.put(`/tour_stops/${stopId}`, payload));
}

/**
 * Elimina una tappa
 */
function deleteStop(stopId) {
  return unwrap(api.delete(`/tour_stops/${stopId}`));
}

export const toursApi = {
  // routes
  listRoutes,
  getRoute,
  createRoute,
  updateRoute,
  deleteRoute,

  // stops
  listStops,
  createStop,
  updateStop,
  deleteStop,
};

export default toursApi;
